<div class="sectionInspire">
    <div class="large-wrapper">
        <!-- <div class="line1"></div> -->
        <div class="magic">
            <span class="giantInspire">Inspire</span>
            <p class="inspireContent"><?php if(get_field('paragraph_content')): the_field('paragraph_content'); endif;?></p>
        </div>
    </div>
</div>