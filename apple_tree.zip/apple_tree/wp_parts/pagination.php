<!-- pagination -->
<div class="pagination">
	<?php BCwp_pagination(); ?>
</div>
<!-- /pagination -->
